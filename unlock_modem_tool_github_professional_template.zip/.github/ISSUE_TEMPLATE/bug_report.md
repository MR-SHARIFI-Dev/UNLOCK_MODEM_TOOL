---
name: Bug report
about: Report a problem with the public page or release package
title: "[Bug]: "
labels: bug
assignees: ""
---

## Problem

Describe the issue.

## Steps

1.
2.
3.

## Expected result

## Screenshot

## System

- Windows version:
- App version:
- Device model:

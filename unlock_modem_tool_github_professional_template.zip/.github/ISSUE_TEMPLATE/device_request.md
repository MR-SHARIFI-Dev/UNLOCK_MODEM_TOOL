---
name: Device compatibility request
about: Request review for a modem/device model
title: "[Device]: "
labels: compatibility
assignees: ""
---

## Device model

## Firmware version

## Region/operator

## Notes

Do not post private identifiers, license keys, IMEI, or sensitive data.
